package com.example.ads_url

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
