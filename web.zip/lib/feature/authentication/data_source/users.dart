import 'package:ads_url/feature/authentication/model/user_model.dart';

class Users{
  static List<UserModel> users = [
    UserModel(userName: 'Shivangi', password: '1234', emailId: 'abc@gmail.com'),
    UserModel(userName: 'Shivi', password: '1111', emailId: 'xyz@gmail.com'),


  ]  ;
}