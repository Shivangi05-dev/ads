
import 'package:flutter/cupertino.dart';

class UserModel{
  final String  userName;
  final String password;
  final String emailId;

  UserModel({ @required this.emailId,@required this.userName,@required this.password});



}